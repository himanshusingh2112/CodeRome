// All the events

export const ACTIONS = {
  JOIN: "join",
  JOINED: "joined",
  DISCONNECTED: "disconnected",
  CODE_CHANGE: "code-change",
  SYNC_CODE: "sync-code",
  LEAVE: "leave",
  SYNC_OUTPUT: "sync-output",
  ROOM_FULL : "room-full"

};
